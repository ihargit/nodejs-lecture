module.exports = {
    secretToken: 'fouhqeripughipuerhgpiuerhg'
}