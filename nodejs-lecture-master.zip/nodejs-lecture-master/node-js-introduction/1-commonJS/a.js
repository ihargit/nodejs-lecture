function add(a, b) {
    return a + b;
}

/*
es6 modules analogue:
export default add; 
*/
module.exports = add;