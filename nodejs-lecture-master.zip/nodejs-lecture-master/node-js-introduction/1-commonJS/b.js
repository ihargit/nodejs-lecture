function mul(a, b) {
    return a + b;
}

/*
es6 modules analogue:
export function mul(a, b) {
    return a + b;
}
*/
module.exports = {
    mul,
}