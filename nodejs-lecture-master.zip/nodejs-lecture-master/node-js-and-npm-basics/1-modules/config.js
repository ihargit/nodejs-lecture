const config = {
  apiKey: '111-222-333',
  user: 'John',
  port: 3000,
}

module.exports = config;