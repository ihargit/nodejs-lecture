const { log } = require('../utils');

function init() {
  log('I am ready!');
}

module.exports = {
  init
};